
public class Driver {
    public static void main(String args[])
    {
        Games game = new Games();

        game.textParser();
    }
}
