package ca.bcit.comp1451.session2.labB;

public class Driver {
    public static void main(String args[])
    {
        Games game = new Games();
        game.playChicago();
    }
}
